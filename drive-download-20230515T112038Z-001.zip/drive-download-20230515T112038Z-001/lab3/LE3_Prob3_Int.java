interface SwimBehaviour{
  void swim();
}

interface FlyBehaviour{
  void fly();
}

interface QuackBehaviour{
  void quack();
}