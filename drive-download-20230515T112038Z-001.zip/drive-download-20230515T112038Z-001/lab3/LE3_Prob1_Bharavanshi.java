abstract class Bharatvanshi{
    abstract void fight();
}