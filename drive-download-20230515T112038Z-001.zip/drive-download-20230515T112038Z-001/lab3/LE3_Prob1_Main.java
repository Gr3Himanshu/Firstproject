public class Main
{
	public static void main(String[] args) {
		Bharatvanshi p = new Pandavs();
		Bharatvanshi k = new Kauravs();
		Pandavs pd = new Pandavs();
		Kauravs kv = new Kauravs();
		pd.kind();
		p.fight();
	}
}