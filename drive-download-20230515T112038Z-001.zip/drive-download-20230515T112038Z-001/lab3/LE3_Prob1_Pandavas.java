class Pandavs extends Bharatvanshi{
    public void kind(){
        System.out.println("Kind");
    }
    public void obey(){
        System.out.println("Obedient");
    }
    @Override
    void fight(){
        System.out.println("Fighters");
    }
}