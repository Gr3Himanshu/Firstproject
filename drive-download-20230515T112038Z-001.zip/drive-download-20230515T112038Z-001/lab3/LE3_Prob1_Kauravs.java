class Kauravs extends Bharatvanshi{
    public void cruel(){
        System.out.println("cruel");
    }
    public void disobey(){
        System.out.println("disobedient");
    }
    @Override
    void fight(){
        System.out.println("Fighters");
    }
}